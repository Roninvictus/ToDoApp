package com.example.todo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    //declaring private variable properties and their type.
    private lateinit var editText: EditText
    private lateinit var addButton: Button
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>

    //Immutable reference list with mutable content
    private val tasks = mutableListOf<String>()

    //declare onCreate method as override of the same method from the parent class
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)
        addButton = findViewById(R.id.addButton)
        listView = findViewById(R.id.listView)

        //set up an adapter for a ListView
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_checked, tasks)
        listView.adapter = adapter

        addButton.setOnClickListener {
            val task = editText.text.toString().trim()
            if (task.isNotEmpty()) { //check whether the "task" string is not empty
                tasks.add(task) //add the "task" string to the list of tasks
                adapter.notifyDataSetChanged() //update the display to show new task that was added.
                editText.text.clear()
            }
        }

        listView.setOnItemClickListener { _, view, position, _ ->
            val isChecked = (view as CheckedTextView).isChecked
            listView.setItemChecked(position, !isChecked) //toggle state of the checkbox for clicked item
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            tasks.removeAt(position)
            adapter.notifyDataSetChanged()
            true//indicates that the long click event was handled
        }

    }
}